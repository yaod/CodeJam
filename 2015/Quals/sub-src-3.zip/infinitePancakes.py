cases = []
with open('B-small-attempt0.in') as f:
    n = int(f.readline())
    for i,line in enumerate(f):
        if i%2 == 0:
            n = int(line)
        else:
            diners = line.split()
            diners = [int(e) for e in diners]
            if n == 1:
                time = min(1+(diners[0]+1)//2,diners[0])
            else:
                diners.sort()
                time = diners[n-1]
                mD = diners[n-1]
                mD2 = diners[n-2]
                while mD > 3 and 1+max((mD+1)//2,mD2)<time:
                    time = 1+max((mD+1)//2,mD2)
                    diners[n-1] = (mD+1)//2
                    diners.sort()
                    mD = diners[n-1]
                    mD2 = diners[n-2]
            cases.append('Case #'+str(i//2+1)+': '+str(time)+'\n')

with open('B-small-attempt0.out','w+') as g:
    g.writelines(cases)